/*
 *
 * Copyright (C) 2008 Nageswar Keetha (nk2340@columbia.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 *
 */

#include "hash_map_compat.h"
#include "StateQueue.h"
#include "ModelChecker.h"
#include <pthread.h> 
#include <string.h> 
#include <stdio.h> 
#include <stdlib.h> 


enum {
 	MEMORY_ALLOCATION_ERROR = 1,
	COULDNOT_POP_STATE_FROM_Q = 2,
	COULDNOT_GET_TOP_STATE_FROM_Q = 3,
	FILE_RROR =4,
	UNKNOWN_EXCEPTION =5
}; 
using namespace std;

BFSQueue globalQ;
visited_tbl_t gVisitedStates;
ckpt_tbl_t gckpts;
visited_tbl_t::iterator g_vit;
visited_pods  vpods;
struct podname {
	char podnm[256];

};
vector<podname> vpds;
pthread_mutex_t pop_mutex; 
popstateres *
pop_1_svc(void *argp, struct svc_req *rqstp)
{
	static popstateres  result;
	int errorno = 0;
	pthread_mutex_lock(&pop_mutex); 
	State *s = globalQ.pop(); 
	pthread_mutex_unlock(&pop_mutex); 
     
	if(s)
	{
		
		result.popstateres_u.st.start = s->start; 
		result.popstateres_u.st.id = s->id;
		result.popstateres_u.st.sig = s->sig;
		result.popstateres_u.st.trace.trace_val =(u_char*) malloc(s->trace.size());
		if(result.popstateres_u.st.trace.trace_val != NULL)
		{  
			printf ("POP State: ");
			printf ("%d ",result.popstateres_u.st.start);
			printf ("%d ",result.popstateres_u.st.id);
			printf ("%d ",result.popstateres_u.st.sig);
			printf ("Trace:");
			int i=0;
		       for(; i<s->trace.size();i++) 
				result.popstateres_u.st.trace.trace_val[i] = s->trace[i];
			result.popstateres_u.st.trace.trace_len = s->trace.size();
			for(i=0; i< result.popstateres_u.st.trace.trace_len;i++) 
				printf ("%d",result.popstateres_u.st.trace.trace_val[i]);
			printf ("\n");
		}
		else
		{
			errorno = MEMORY_ALLOCATION_ERROR;
		}
	}
	else 
	{
	 	errorno = COULDNOT_POP_STATE_FROM_Q;
	}
 	if(errorno > 0) 
	     printf("Failed in POP State,  Error: %d\n", errorno); 

	 return &result;
}

void *
push_1_svc(RpcState *argp, struct svc_req *rqstp)
{
	static char * result;
	int errorno =0;
	try {
		State *s = new State();
		if(s)
		{
			s->start = argp->start; 
			s->id = argp->id;
			s->sig = argp->sig;
			printf("PUSH State: %d,%d,%d\n",argp->start,argp->id,argp->sig);
			printf("trace:");
			for(int i=0; i< argp->trace.trace_len;i++) { 
				s->trace.push_back(argp->trace.trace_val[i]);
				printf("%d",argp->trace.trace_val[i]);
			}
			printf("\n");
			sleep(1);//demo purposes
			globalQ.push(s);
		}
		else 
		  errorno = MEMORY_ALLOCATION_ERROR;
	}
	catch(...)
	{
		errorno = UNKNOWN_EXCEPTION;
	}
	if(errorno > 0) 
	     printf("Failed in PUSH state, Error: %d\n", errorno); 
	return (void *) &result;
}

popstateres *
top_1_svc(void *argp, struct svc_req *rqstp)
{
	static popstateres  result;
	int errorno =0; 
	try{
		State *s = globalQ.top(); 
		if(s)
		{
			result.popstateres_u.st.start = s->start; 
			result.popstateres_u.st.id = s->id;
			result.popstateres_u.st.sig = s->sig;
			result.popstateres_u.st.trace.trace_val =(u_char*) malloc(s->trace.size());
			int i=0;
		       for(; i<s->trace.size();i++) 
				result.popstateres_u.st.trace.trace_val[i] = s->trace[i];
			result.popstateres_u.st.trace.trace_len = s->trace.size();
		}
		else
		      errorno = COULDNOT_GET_TOP_STATE_FROM_Q;
	}
	catch(...)
	{
		 errorno = UNKNOWN_EXCEPTION;
	}
	if( errorno > 0) 
	     printf("Failed to get TOP state in Queue, Error: %d\n",  errorno); 
	return &result;
}

bool_t *
printq_1_svc(void *argp, struct svc_req *rqstp)
{
	static bool_t  result;
	return &result;
}
bool_t *
save_states_to_file_1_svc(void *argp, struct svc_req *rqstp)
{
	static bool_t  result;
	return &result;
}

bool_t *
restore_states_from_file_1_svc(void *argp, struct svc_req *rqstp)
{
	static bool_t  result;
	
	return &result;
}

bool_t *
empty_1_svc(void *argp, struct svc_req *rqstp)
{
	static bool_t  result;
	result =  globalQ.empty();
	return &result;
}

int *
size_1_svc(void *argp, struct svc_req *rqstp)
{
	static int  result;
	result = globalQ.size();
	return &result;
}
visitedstateres *
getfirstvisitedstate_1_svc(void *argp, struct svc_req *rqstp)
{
	static visitedstateres  result;
	 g_vit = gVisitedStates.begin();
	result.visitedstateres_u.vst.sig = (*g_vit).first;
	result.visitedstateres_u.vst.id = (*g_vit).second;
	g_vit++;
	return &result;
}
int *
setvisitedstate_1_svc(RpcVisitedStatePair *argp, struct svc_req *rqstp)
{

	pthread_mutex_t vs_mutex; 
	static int  result;
	int  errorno =0; 
	try 
	{       pthread_mutex_lock(&vs_mutex); 
		gVisitedStates[argp->sig] = argp->id;
		pthread_mutex_unlock(&vs_mutex); 
	}
	catch(...)
	{
		 errorno = UNKNOWN_EXCEPTION;
	}
	if( errorno > 0) 
	     printf("Failed set visited State, Error: %d\n",  errorno); 
	return &result;
}

visitedstateres *
getnextvisitedstate_1_svc(void *argp, struct svc_req *rqstp)
{
	static visitedstateres  result;
	 if(g_vit != gVisitedStates.end()){

		result.visitedstateres_u.vst.sig = (*g_vit).first;
		result.visitedstateres_u.vst.id = (*g_vit).second;
		g_vit++;
	}
	
	return &result;
}

bool_t *
isitvisitedstate_1_svc(signature_t *argp, struct svc_req *rqstp)
{
	static bool_t  result;

	result = exists(*argp, gVisitedStates);	
	
	return &result;
}

bool_t *
resetstatequeue_1_svc(void *argp, struct svc_req *rqstp)
{
	static bool_t  result;
	while(!globalQ.empty())
		globalQ.pop();

	return &result;
}
int *
visitedstatessize_1_svc(void *argp, struct svc_req *rqstp)
{
	static int  result;
	result = gVisitedStates.size();

	return &result;
}
int *
getvisitedstate_1_svc(signature_t *argp, struct svc_req *rqstp)
{
	static int  result;
	int errorno = 0;
	try
	{
		result = gVisitedStates[*argp];
	}
	catch(...)
	{
		 errorno = UNKNOWN_EXCEPTION;
	}
	if(errorno > 0) 
	     printf("Failed to get a Visited State, Error: %d\n", errorno); 

	return &result;
}
int *
setcp_1_svc(RpcCP_idPair *argp, struct svc_req *rqstp)
{
	static int  result;
	try 
	{	
		Checkpoint *cp = new Checkpoint;
		cp->data = new char[argp->rcp.data.data_len];
		if(cp->data)
		{
			memcpy(cp->data, argp->rcp.data.data_val,argp->rcp.data.data_len);
			cp->len = (int) argp->rcp.data.data_len;
			cp->parent_id = argp->rcp.parent_id;
			cp->trace.resize(argp->rcp.trace.trace_len, 0);
			for(int i= 0; i<  argp->rcp.trace.trace_len; i++)
			{
				cp->trace[i] = argp->rcp.trace.trace_val[i];
				//printf("in SetCP-- %d %d\n",i, cp->trace[i]);
			}
			
			gckpts[argp->id] = cp;
		//	printf("gckpts[%d] = cp\n",argp->id);
		}
		else
			result = MEMORY_ALLOCATION_ERROR;
	}
	catch(...)
	{
		 result = UNKNOWN_EXCEPTION;
	}
	if(result > 0) 
	     printf("Checkpoint hash map assignment fails, Error: %d\n", result); 

	return &result;
}

rpccpres *
getcp_1_svc(int *argp, struct svc_req *rqstp)
{
	static rpccpres  result;
	int errorno =0;
	try
	{
		const Checkpoint *ckpt = gckpts[(*argp)];
		result.rpccpres_u.cp.data.data_len = ckpt->len;
		result.rpccpres_u.cp.data.data_val = (char*)malloc(result.rpccpres_u.cp.data.data_len);
		if(result.rpccpres_u.cp.data.data_val)
		{
			memcpy(result.rpccpres_u.cp.data.data_val, ckpt->data,ckpt->len);
			result.rpccpres_u.cp.parent_id = ckpt->parent_id;
			result.rpccpres_u.cp.trace.trace_len =(u_int) ckpt->trace.size();
			result.rpccpres_u.cp.trace.trace_val = (u_char*) malloc(result.rpccpres_u.cp.trace.trace_len);
			for(int i= 0; i<  result.rpccpres_u.cp.trace.trace_len; i++)
			{
				result.rpccpres_u.cp.trace.trace_val[i] = ckpt->trace[i];
			}
		}
		else
			errorno = MEMORY_ALLOCATION_ERROR;
	}
	catch(...)
	{
		 errorno = UNKNOWN_EXCEPTION;
	}
	if(errorno > 0) 
	     printf("Getting Checkpoint from  hash map fails, Error: %d\n", errorno); 
		
	return &result;
}

int *
getcpsize_1_svc(void *argp, struct svc_req *rqstp)
{
	static int  result;
	return &result;
}
int iVp =0;
void *
setpodname_1_svc(char **argp, struct svc_req *rqstp)
{
	static int  result;
	int  errorno =0;
	podname px;
 
	try 
	{  
		strcpy(px.podnm,*argp);
		vpods[*argp] = iVp++ ;
		vpds.push_back(px);
	        printf("ckpt and brnch a  POD: %s\n", px.podnm); 


	}
	catch(...)
	{
		 errorno = UNKNOWN_EXCEPTION;
	}
	if( errorno > 0) 
	     printf("Failed set visited State, Error: %d\n",  errorno); 
	return &result;
	/*
	 * insert server code here
	 */

	return (void *) &result;
}

bool_t *
doespodexist_1_svc(char **argp, struct svc_req *rqstp)
{
	static bool_t  result;
//       printf("Check POD exisits with same stateid: %s\n",  *argp); 
	result =0;
	for(int i=0; i<vpds.size();i++)
	{
	
		if(strcmp(vpds[i].podnm,*argp)==0)
		{
		  result=1;
		  break;	
		}
	}	
	//result = exists(*argp, vpods);	

	/*
	 * insert server code here
	 */

	return &result;
}

