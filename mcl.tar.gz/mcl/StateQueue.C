/*
 *
 * Copyright (C) 2008 Junfeng Yang (junfeng@cs.columbia.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 *
 */


#include "hash_map_compat.h"
#include "StateQueue.h"
#include "ModelChecker.h"


using namespace std;

ostream& operator<<(ostream& o, const StateQueue& q)
{
	return q.print(o);
}
/*
 *
 * The following code author: Nageswar Keetha (nk2340@.columbia.edu)
 *
*/


int  CheckPointing::SetCP(int id,Checkpoint cp)
{	int  *result;
	RpcCP_idPair  setcp_1_arg;
	setcp_1_arg.id = id;
	int j =0;

	setcp_1_arg.rcp.data. data_len = cp.len;
	setcp_1_arg.rcp.data.data_val = (char*) malloc (cp.len);
	memcpy(setcp_1_arg.rcp.data.data_val,cp.data,cp.len);
	setcp_1_arg.rcp.parent_id = cp.parent_id;
	setcp_1_arg.rcp.trace.trace_len = (u_int) cp.trace.size();
	if(setcp_1_arg.rcp.trace.trace_len > 0)
	{
		setcp_1_arg.rcp.trace.trace_val = (u_char*) malloc (cp.trace.size());
		for(int i=0; i<  cp.trace.size(); i++)
			setcp_1_arg.rcp.trace.trace_val[i] = cp.trace[i];
	}
	else
		setcp_1_arg.rcp.trace.trace_val = NULL;
	printf("Checkpoint trace length: %d\n",setcp_1_arg.rcp.trace.trace_len);
	printf("Checkpoint DATA length: %d\n",setcp_1_arg.rcp.data.data_len);
//
	CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}
//
	result = setcp_1(&setcp_1_arg, clnt);
	if (result == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	delete setcp_1_arg.rcp.data.data_val;
	delete setcp_1_arg.rcp.trace.trace_val;
	clnt_destroy(clnt);
	return *result;
}
Checkpoint CheckPointing::GetCP(int id)
{       rpccpres  *result;
	int  getcp_1_arg;
	CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}


	result = getcp_1(&id, clnt);
	if (result == (rpccpres *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	
	Checkpoint cp;
	cp.len = result->rpccpres_u.cp.data.data_len;
	cp.data = (char*) malloc(cp.len);
	memcpy(cp.data, result->rpccpres_u.cp.data.data_val,cp.len);
	cp.parent_id = result->rpccpres_u.cp.parent_id;
	for(int i=0; i< result->rpccpres_u.cp.trace.trace_len; i++)
		cp.trace.push_back(result->rpccpres_u.cp.trace.trace_val[i]);
	clnt_destroy(clnt);
	return cp;	
}
int  VisitedStates::NumStates()
{	int  *result;
	char *visitedstatessize_1_arg;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result = visitedstatessize_1((void*)&visitedstatessize_1_arg, clnt);
	if (result == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	clnt_destroy(clnt);
	return *result;
}
int VisitedStates::Setvisitedstate(signature_t sig,int id)
{
	int  *result;
	RpcVisitedStatePair  setvisitedstate_1_arg;
	setvisitedstate_1_arg.sig = sig;
	setvisitedstate_1_arg.id = id;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result = setvisitedstate_1(&setvisitedstate_1_arg, clnt);
	if (result == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	clnt_destroy(clnt);
	return *result;
}
int VisitedStates:: Gettvisitedstate(signature_t sig) 
{
	int  *result;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}
	result = getvisitedstate_1(&sig, clnt);
	if (result == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	clnt_destroy(clnt);
	return *result;
}
bool VisitedStates::IsVisitedState(signature_t sig)
{
	bool_t  *result;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}
	result = isitvisitedstate_1(&sig, clnt);
	if (result == (bool_t *) NULL) {
		clnt_perror (clnt, "call failed");
	}
clnt_destroy(clnt);
	return *result;
}

bool ExpQueueClient::empty() const {
	bool_t  *result;
	char *empty_1_arg;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result = empty_1((void*)&empty_1_arg, clnt);
	if (result == (bool_t *) NULL) {
		clnt_perror (clnt, "call failed");
	}
clnt_destroy(clnt);
        return (*result);
}
int ExpQueueClient::size () const 
{
	int  *result;
	char *size_1_arg;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result = size_1((void*)&size_1_arg, clnt);
	if (result == (int *) NULL) {
		clnt_perror (clnt, "call failed");
	}
        clnt_destroy(clnt);
	return *result;

}
void ExpQueueClient::push (State *s) 
{
		RpcState  push_1_arg;
		void  *result;
		push_1_arg.start = s->start; 
		push_1_arg.id = s->id;
		push_1_arg.sig = s->id;
		push_1_arg.trace.trace_len = s->trace.size();
		push_1_arg.trace.trace_val = (u_char*)malloc(s->trace.size() * (sizeof(u_char)));

		int i=0;
		printf("TRACE:%d",push_1_arg.trace.trace_len);
		
		for(; i< push_1_arg.trace.trace_len;i++)
		{ 
			push_1_arg.trace.trace_val[i] = s->trace[i];
			printf("%d",s->trace[i]);
		
		}
		printf("\n");
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

		result = push_1(&push_1_arg, clnt);
		if (result == (void *) NULL) {
			clnt_perror (clnt, "call failed");
		}
		clnt_destroy(clnt);
                delete push_1_arg.trace.trace_val;
	
	}

State* ExpQueueClient::pop() 
{
		popstateres  *result;
		char *pop_1_arg;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}
		
		result = pop_1((void*)&pop_1_arg, clnt);
		if (result == (popstateres *) NULL) {
			clnt_perror (clnt, "call failed");
		}

		printf ("CLIENT POP: ");
		printf ("%d ",result->popstateres_u.st.start);
		printf ("%d ",result->popstateres_u.st.id);
		printf ("%d ",result->popstateres_u.st.sig);
		int i;
		for(i=0; i< result->popstateres_u.st.trace.trace_len;i++) 
		printf ("%d",result->popstateres_u.st.trace.trace_val[i]);
		printf ("\n");
		State *s = new State();
		s->start = result->popstateres_u.st.start;
		s->id = result->popstateres_u.st.id;
		s->sig = result->popstateres_u.st.sig;
		for(i=0; i< result->popstateres_u.st.trace.trace_len;i++)
			s->trace.push_back(result->popstateres_u.st.trace.trace_val[i]);
		delete result->popstateres_u.st.trace.trace_val;
		clnt_destroy(clnt);
		return dynamic_cast<State*>(s);
	}
State* ExpQueueClient::top() const
{
	popstateres  *result;
	char *top_1_arg;
CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result = top_1((void*)&top_1_arg, clnt);
	if (result == (popstateres *) NULL) {
		clnt_perror (clnt, "call failed");
	}
	State *s = new State(); 
	s->start = result->popstateres_u.st.start;
	s->id = result->popstateres_u.st.id;
	s->sig = result->popstateres_u.st.sig;
	int i=0;
	for(i=0; i< result->popstateres_u.st.trace.trace_len;i++)
		s->trace.push_back(result->popstateres_u.st.trace.trace_val[i]);
	delete result->popstateres_u.st.trace.trace_val;
        clnt_destroy(clnt);
}
void  VisitedStates::SetPOD(	char * setpodname_1_arg) const
{
	void  *result_19;

CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result_19 = setpodname_1(&setpodname_1_arg, clnt);
	if (result_19 == (void *) NULL) {
		clnt_perror (clnt, "call failed");
	}
        clnt_destroy(clnt);
}
bool  VisitedStates::PODExists(char * doespodexist_1_arg) const
{
	bool_t  *result_20;

CLIENT *clnt;
	clnt = clnt_create (get_option(rpcmcserver, host), STATEQUEUE, FIRSTVERSION, "tcp");
	if (clnt == NULL) {
		clnt_pcreateerror (get_option(rpcmcserver, host));
		exit (1);
	}

	result_20 = doespodexist_1(&doespodexist_1_arg, clnt);
	if (result_20 == (bool_t *) NULL) {
		clnt_perror (clnt, "call failed");
	}

        clnt_destroy(clnt);
	return *result_20;
}


	
