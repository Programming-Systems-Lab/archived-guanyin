/*
 *
 * Copyright (C) 2008 Junfeng Yang (junfeng@cs.columbia.edu)
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2, or (at
 * your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
 * USA
 *
 */


/* A simple test case. Non-deterministically increment either x or
   y by 1, wrap around if x or y hit MAX. Print out an trace
   explode.trace.0 if x + y reaches 2 * (MAX - 1).  Use ./xywalk -r
   explode.trace.0 to replay the trace */

#include "mcl.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <iostream>

using namespace std;

const int MAX = 5;

class Test: public TestHarness {
    int x, y;
    int ntrans;
    
public:
    Test() {
        x = 0;
        y = 0;
        ntrans = 0;
    }


    void exit(void) {
	int expected =  MAX*MAX*2;
	if (ntrans == expected)
            printf ("total trans %d is expected.\n", ntrans);
	else
            printf ("Something wrong with the modelchecker(actual transitions %d != expectd %d!!!\n", ntrans, expected);
    }
    
    void run_one_transition(void) {
	int op = explode_random(2);

	// run transition here
	printf ("(%d, %d)", x, y);
		
	switch (op) {
	case 0:
		x += 1;
		x %= MAX;
		break;
	case 1:
		y += 1;
		y %= MAX;
		break;
	}
	if (x + y == 2 * MAX - 2) {
		printf (" -> bug\n");
		fflush(NULL);
		error("bug", "bug");
	}
	ntrans ++;
	printf (" -> (%d, %d)\n", x, y);
	return;
    }

    int checkpoint_length(void) {
	return sizeof x + sizeof y;
    }

    void checkpoint(char* buf, int len) {
	char* p = buf;
	memcpy (p, (char*)&x, sizeof x);
	p += sizeof x;
	memcpy (p, (char*)&y, sizeof y);
    }
    
    void restore(const char* buf, unsigned l) {
	assert(l == sizeof x + sizeof y);
	const char *p = buf;
	memcpy((char*)&x, p, sizeof x);
	p += sizeof x;
	memcpy((char*)&y, p, sizeof y);
    }

    signature_t get_sig (void)
    {
	//cout << "sig = " << (x<<16)+y << endl;
	return (x<<16) + y;
    }
};

int main(int argc, char *argv[])
{
    explode_process_cmd_args(argc, argv);
    explode_check(new Test);
}
