#!/bin/bash
set +x
cd /home/junfeng/explode/check
./explode_server
