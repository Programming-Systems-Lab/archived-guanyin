#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x71cacc90, "struct_module" },
	{ 0xa5423cc4, "param_get_int" },
	{ 0xcb32da10, "param_set_int" },
	{ 0x60a4461c, "__up_wakeup" },
	{ 0x96b27088, "__down_failed" },
	{ 0xf2a644fb, "copy_from_user" },
	{ 0x2da418b5, "copy_to_user" },
	{ 0x5f35223d, "check_disk_change" },
	{ 0x819aa9dc, "ek_hooks" },
	{ 0x85f16fcf, "end_request" },
	{ 0xa2427711, "elv_next_request" },
	{ 0x69900829, "_spin_unlock" },
	{ 0xc88c7ada, "_spin_lock" },
	{ 0x1075bf0, "panic" },
	{ 0xc3fe6db4, "__spin_lock_init" },
	{ 0xe682b2ed, "add_disk" },
	{ 0x1d26aa98, "sprintf" },
	{ 0x117262da, "blk_queue_hardsect_size" },
	{ 0x2d7e848f, "blk_init_queue" },
	{ 0xc0bcab7b, "alloc_disk" },
	{ 0x71a50dbc, "register_blkdev" },
	{ 0x107d6ba3, "__get_free_pages" },
	{ 0xd6ee688f, "vmalloc" },
	{ 0x1b7d4074, "printk" },
	{ 0xb5a459dc, "unregister_blkdev" },
	{ 0xc218fbe1, "put_disk" },
	{ 0x4bbeffbe, "del_gendisk" },
	{ 0xd2f1b941, "blk_cleanup_queue" },
	{ 0x2fd1d81c, "vfree" },
	{ 0x9941ccb8, "free_pages" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "D5FDD1A3DEE0DC7116DD30B");
