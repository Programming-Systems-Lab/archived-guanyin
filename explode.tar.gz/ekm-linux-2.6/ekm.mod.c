#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

static const struct modversion_info ____versions[]
__attribute_used__
__attribute__((section("__versions"))) = {
	{ 0x71cacc90, "struct_module" },
	{ 0xd8118f82, "per_cpu__current_task" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xc0bcab7b, "alloc_disk" },
	{ 0x314072b5, "mem_map" },
	{ 0xd0d8621b, "strlen" },
	{ 0xfef9c77c, "_read_lock" },
	{ 0x819aa9dc, "ek_hooks" },
	{ 0xc88c7ada, "_spin_lock" },
	{ 0xb61e7617, "enable_choose" },
	{ 0x9d679f4a, "names_cachep" },
	{ 0x9d75ed43, "_spin_lock_irqsave" },
	{ 0x7d30247f, "lookup_bdev" },
	{ 0xe2d5255a, "strcmp" },
	{ 0x7c60d66e, "getname" },
	{ 0x1037b812, "tasklist_lock" },
	{ 0x1b7d4074, "printk" },
	{ 0x4bbeffbe, "del_gendisk" },
	{ 0x1075bf0, "panic" },
	{ 0x2da418b5, "copy_to_user" },
	{ 0xedecf313, "disable_choose" },
	{ 0x6c2e3320, "strncmp" },
	{ 0x98da2b97, "kmem_cache_free" },
	{ 0x71a50dbc, "register_blkdev" },
	{ 0xe49e22e1, "_spin_unlock_irqrestore" },
	{ 0xdf9ac6d9, "get_super" },
	{ 0xadccac32, "fput" },
	{ 0x69900829, "_spin_unlock" },
	{ 0xb5a459dc, "unregister_blkdev" },
	{ 0xdc0b6c58, "ek_hooks_lock" },
	{ 0xb2fd5ceb, "__put_user_4" },
	{ 0x107d6ba3, "__get_free_pages" },
	{ 0xc218fbe1, "put_disk" },
	{ 0x6b2dc060, "dump_stack" },
	{ 0xa9060933, "drop_super" },
	{ 0x34e16e0b, "wake_up_process" },
	{ 0x605d6ebe, "_read_unlock" },
	{ 0x9941ccb8, "free_pages" },
	{ 0x37a0cba, "kfree" },
	{ 0x2e60bace, "memcpy" },
	{ 0xff458586, "choose_enabled" },
	{ 0xe682b2ed, "add_disk" },
	{ 0xfbb2345d, "set_user_nice" },
	{ 0xe9b51dfb, "fget" },
	{ 0x993d1eff, "find_task_by_pid" },
	{ 0xf2a644fb, "copy_from_user" },
	{ 0xa18b439e, "bdput" },
	{ 0x760a0f4f, "yield" },
	{ 0xe914e41e, "strcpy" },
};

static const char __module_depends[]
__attribute_used__
__attribute__((section(".modinfo"))) =
"depends=";


MODULE_INFO(srcversion, "0618AB251BF138BE23940D8");
